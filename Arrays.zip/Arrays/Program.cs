﻿using System;

namespace Console
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numeros = { 12, 15, 18, 22, 235, 98};

            numeros[3] = 999;

            int[] numeros2 = new int[10];

            for(int contador = 0; contador <= numeros.Length; contador++)
            {
               numeros2[contador] = numeros[contador];
            }

            numeros = numeros2;

            numeros2[3] = 111;

            for(int contador = 0; contador <= numeros.Length; contador++)
            {
                System.Console.WriteLine(" El elemento " + (contador + 1) +
                " es igual a " + numeros[contador]);
            }

            Console.ReadKey();
        }
    }
}
